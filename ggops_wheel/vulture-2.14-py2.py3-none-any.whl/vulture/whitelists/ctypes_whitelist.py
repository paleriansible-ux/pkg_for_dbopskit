from ctypes import _CFuncPtr, _Pointer

_CFuncPtr.argtypes
_CFuncPtr.errcheck
_CFuncPtr.restype

_Pointer.contents
