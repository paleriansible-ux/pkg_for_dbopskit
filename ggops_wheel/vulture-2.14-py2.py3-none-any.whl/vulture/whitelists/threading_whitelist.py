import threading

threading.Thread.daemon
threading.Thread.name
threading.Thread.run
