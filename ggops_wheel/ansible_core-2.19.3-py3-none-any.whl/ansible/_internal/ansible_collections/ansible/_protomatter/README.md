"Protomatter - an unstable substance which every ethical scientist in the galaxy has denounced as dangerously unpredictable."

"But it was the only way to solve certain problems..."

This Ansible Collection is embedded within ansible-core.
It contains plugins useful for ansible-core's own integration tests.
They have been made available, completely unsupported,
in case they prove useful for debugging and troubleshooting purposes.

> CAUTION: This collection is not supported, and may be changed or removed in any version without prior notice.
Use of these plugins outside ansible-core is highly discouraged.
