# -*- coding: utf-8 -*-


def èèèè(òòòò):
    pass
