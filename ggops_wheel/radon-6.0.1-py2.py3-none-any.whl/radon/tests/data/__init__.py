# -*- coding: utf-8 -*-


def fun(arg):
    a = 'èèèè'
